# 🫒 Bloglivas

**Bloglivas** és una xarxa social dedicada exclusivament al món de les olives i tot el que les envolta: cultiu, varietats, receptes, curiositats, etc...

## 🌿 Descripció

Bloglivas neix com un punt de trobada per a amants de les oliveres i les olives. Els usuaris poden compartir publicacions, seguir-se entre ells, comentar, reaccionar i descobrir novetats sobre aquest meravellós fruit mediterrani.

## 📦 Instal·lació

1. Clona el repositori:

   ```bash
   git clone https://github.com/RogerAbelloPerera/bloglivas.git
